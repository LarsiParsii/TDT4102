#pragma once

int randomWithLimits(int lowerLimit, int upperLimit);