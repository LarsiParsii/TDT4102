#pragma once

namespace TDT4102 {
	struct Point {
		int x = 0;
		int y = 0;
	};	
}
