#pragma once

// Prototypes
void testCallByValue(void);
void testCallByReference(void);
void testSwapByReference(void);
void testPrintStudent(void);
void testIsInProgram(void);
void testString(void);
void testRandomizeString(void);