#pragma once

// Prototypes
void playMastermind(void);
int checkCharactersAndPosition(string guess, string code);
int checkCharacters(string guess, string code, int letters);