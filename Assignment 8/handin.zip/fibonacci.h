#pragma once

// Prototypes
void fillInFibonacciNumbers(int *result, int length);
void printArray(int *arr, int length);
void createFibonacci();