#pragma once
#include "std_lib_facilities.h"

#define COLUMNS 3

void inputToFile(filesystem::path path);
void addLineNumbersToFile(filesystem::path path);
void printLetterStats(filesystem::path path);